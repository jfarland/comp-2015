Please follow the instructions below when you submit your forecasts: 
1. Please fill your forecasts into the column of "Forecasts" in the submission file.
2. Please change the name of the submission file. Replce "YourFirstName" with your first name and "YourLastNanme" with your last name.
3. Please keep the submission as a csv file.
4. Please include "Energy Analytics External Participant" in the email subject when you send your submission.
5. Please send the submission to bliu8@uncc.edu before 11:45 am ET each day. No late submission.




